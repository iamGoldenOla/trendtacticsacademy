// NOTE: The SUPABASE_ANON_KEY below is incomplete/truncated.
// Please go to your Supabase dashboard, copy the complete anon key, and replace the value below.
// The key should be a complete JWT token starting with 'eyJ' and much longer than the current value.
window.__ENV__ = {
  SUPABASE_URL: "https://uimdbodamoeyukrghchb.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVpbWRib2RhbW9leXVrcmdoY2hiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU0NTYwMzksImV4cCI6MjA4MTAzMjAzOX0.kMFpnaZN04ac94u0wcXJFsS58lX88h8RCM2de3rwYIc"
};