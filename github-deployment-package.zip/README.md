# Trendtactics Academy - Vibe Coding Course

## Overview

This repository contains the HTML version of the Vibe Coding course for Trendtactics Academy. It demonstrates a hybrid approach combining static HTML for course content with React for interactive features.

## Directory Structure

```
├── index.html (Homepage)
├── courses/
│   ├── index.html (Courses listing)
│   └── vibe-coding/
│       ├── index.html (Course overview)
│       └── module-1-understanding-vibe-coding.html (Sample module)
├── integration-guide.html (Integration documentation)
└── HYBRID_DEPLOYMENT_GUIDE.md (Deployment instructions)
```

## Features

### Course Content (HTML)
- Fast-loading, SEO-friendly course pages
- Responsive design that works on all devices
- Easy to update and maintain
- No build process required

### Integration Documentation
- Detailed guide on connecting HTML content with React dashboard
- Shared authentication system
- Progress tracking implementation
- Navigation consistency

## Deployment

This repository is configured for GitHub Pages deployment. Simply enable GitHub Pages in the repository settings to deploy the site.

## Hybrid Approach Benefits

1. **Performance**: HTML pages load instantly without JavaScript overhead
2. **Reliability**: No frontend rendering failures or dependency issues
3. **SEO**: Search engines can easily crawl and index content
4. **Maintenance**: Simple HTML updates without complex build processes
5. **Integration**: Seamless connection to React-powered dashboard features

## Files

- `index.html` - Main homepage
- `courses/` - Directory containing all course content
- `integration-guide.html` - Detailed documentation on HTML/React integration
- `HYBRID_DEPLOYMENT_GUIDE.md` - Deployment instructions

## License

This project is for educational purposes as part of Trendtactics Academy.

## Support

For questions about this implementation, please contact the Trendtactics Academy team.